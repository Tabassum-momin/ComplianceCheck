package com.compliance.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.compliance.service.LoginService;

@Controller
@SessionAttributes("email")
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	
@RequestMapping(value="/", method = RequestMethod.GET)
public String showLoginPage(ModelMap model){
	return "login";
	    }

@RequestMapping(value="/reports", method = RequestMethod.GET)
public String showReports(ModelMap model){
	return "reports";
	    }

@RequestMapping(value="/", method = RequestMethod.POST)
public String showLoginPage(ModelMap model, @RequestParam String email){
//	request.getSession().setAttribute("email", email);
	boolean isValidUser = loginService.validateUser(email);
    if (!isValidUser) {
        model.put("errorMessage", "Compliance Reports are accessible only to registered users");
        return "login";
    }
    model.put("email", email);
    return "questionnaire";
}
}
