package com.compliance.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("email")
public class DataController {

	/*
	 * @Autowired DataService dataService;
	 */

	@RequestMapping(value="/save", method = RequestMethod.PUT)
	public String saveComplianceData(@ModelAttribute ModelMap model, @PathVariable("reportName") String reportName){
		try {
			String email = (String) model.get("email");
			/*String query = queryService.fetchQuery(reportName);
			 *
			 * ResultSet rs = queryService.executeQuery(query);
			 * attachmentService.prepareAttachment(rs, fetchReportColumns(reportName),
			 * reportName); emailService.sendemail(email, reportName+".xls");
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return "successemail";
	}

	@RequestMapping(value="/fetchparams/{reportName}", method = RequestMethod.GET)
	public String fetchParams(ModelMap model,  @PathVariable("reportName") String reportName){
		String fetchReportParam = null;
		if(reportName.equals("errorocc")){
			fetchReportParam = "errorocc";
		}
		else if(reportName.equals("dosedap")){
			fetchReportParam = "dosedap";
		}
		return fetchReportParam;
	}

	public List<String> fetchReportColumns(String reportName){
		List<String> columns = null;
		switch (reportName) {
		case "vascequip":
			System.out.println("vascequip");
			columns = Arrays.asList("SYSTEMID", "HOSPITALNAME", "PRODUCTLINE", "SOFTWAREVERSION", "INSTALLDATE", 
					"FIRST_CONNECTION_TIME", "LAST_CONNECTION_TIME", "EQUIPMENT_TIMEZONE", "POLE", "REGION", "COUNTRY", 
					"EQUIPMENT_ZONE", "LCT", "AREA", "CONNECTIVITYTYPE", "SERVICECENTERNAME", "MODELTYPE", "NAME", "TYPE", 
					"DHRNUMBER", "HAS_SCAT");
			break;
		case "eventsole":
			System.out.println("eventsole");
			columns = Arrays.asList("CREATION_YEAR_MONTH", "EVENT_ID", "SYSTEMID", "POLE", "OLE_SSO", 
					"OLE NAME", "STATUS", "RFS_IF_ANY", "INDICATOR", "DESCRIPTION", "CREATION_DATE", 
					"ASSIGN_DATE", "CLOSE_DATE", "NEW_TO_ASSIGNED_HRS", "ASSIGNED_TO_CLOSED_HRS", "NEW_TO_CLOSED_HRS");
			break;
		case "fsr":
			System.out.println("fsr");
			columns = Arrays.asList("period", "facility", "totalexams", "casessoverdosethreshold3Gy", "cases0_2Gy", "cases2_3Gy", 
					"cases3_5Gy", "cases5_10Gy", "casesover10Gy", "maxdose", "cases0_60mins", "cases60_120mins", "casesover120mins", 
					"examtime0_120mins", "examtime120_240mins", "examtimeover_240mins");
			break;
		case "dosedap":
			System.out.println("dosedap");
			columns = Arrays.asList("EUID", "EXAMSTARTTIME", "EXAMENDTIME", "EXAMTYPE", "CUMULATIVE_DAP", "CUMULATIVE_DOSE", 
					"EXAMDURATION_MIN", "PATIENTID", "PATIENTSEX", "PATIENTAGE", "OPERATOR", "PHYSICIAN", "RADIOLOGIST");
			break;
		case "modality":
			System.out.println("modality");
			columns = Arrays.asList("ID","VALUE");
			break;
		case "errorocc":
			System.out.println("errorocc");
			columns = Arrays.asList("EQUIPMENT_ID", "HOSPITALNAME", "PRODUCTLINE", "SOFTWARE", "TYPE", "ACTIVITYTIME", 
					"CODE", "SHORTTEXT", "RECOVERYCLASS", "DETAILTEXT", "MAJORFUNCTION", "MINORFUNCTION", "RA");
		}
		return columns;
	}
}
