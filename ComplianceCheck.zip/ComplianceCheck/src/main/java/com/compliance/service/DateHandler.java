package com.compliance.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateHandler {

	public static String getDayBefore(int daysBefore) {
		// TODO Auto-generated method stub
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		GregorianCalendar gc = new GregorianCalendar();
		Date date = new Date();
		int dayBefore = gc.get(Calendar.DAY_OF_YEAR);
	    gc.roll(Calendar.DAY_OF_YEAR, daysBefore);
	    int dayAfter = gc.get(Calendar.DAY_OF_YEAR);
	    if(dayAfter > dayBefore) {
	        gc.roll(Calendar.YEAR, -1);
	    }
	    gc.get(Calendar.DATE);
	    java.util.Date yesterday = gc.getTime();
	    String yesterday1 = formatter.format(yesterday);
	    //String yesterday1 = "2020-01-14";
	    //System.out.println("Yesterdays Date = " + yesterday1);
	    return yesterday1;
	    	
	}

}
