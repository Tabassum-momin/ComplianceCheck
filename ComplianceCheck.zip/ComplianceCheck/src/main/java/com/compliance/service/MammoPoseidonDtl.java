package com.compliance.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ge.ibdc.monitoring.bean.MammoPoseidon;

@Service
@Repository()
public class MammoPoseidonDtl {
	
	@Autowired
	private DataSource datasource = null;

	@Qualifier("datasource2")
	@Autowired
	private DataSource destDatasource; 
	

	/**
	 * Get list of active MAMMO Poseidon List 
	 */
	public ArrayList<MammoPoseidon> getMammoPoseidonData(String systemId, String msgDate){

		Connection con = null;
		ArrayList<MammoPoseidon> mammoposeidonlist = null;
		try {  

			con = this.datasource.getConnection();
				    
		    //Sql Query
			final String query = "SELECT activity_datetime,short_text,activity_parameter_name,activity_parameter_value from onwatch.xr_mamo_poseidon_event_dtl where tar_systemid=? and msg_date=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, systemId);
			ps.setString(2, msgDate);

			ResultSet rs=ps.executeQuery();
			if(rs!=null) {				
				mammoposeidonlist =new ArrayList<MammoPoseidon>();
				MammoPoseidon mammo_poseidon = null;
				while(rs.next()) {
					mammo_poseidon= new MammoPoseidon(rs.getString(1), rs.getString(2),rs.getString(3),rs.getString(4));
					mammo_poseidon.setTar_systemid(systemId);
					mammo_poseidon.setMsg_date(msgDate);
					mammoposeidonlist.add(mammo_poseidon);
					//System.out.println(vascerrorlist);
				}
				for (MammoPoseidon s : mammoposeidonlist) { System.out.println(s); break; }
			}
			else {
				return null;
			}

		}catch (Exception e) {
			System.err.println("Error while retreiving mammoposeidonlist:"+e);
			e.printStackTrace();
		}finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
		return mammoposeidonlist;
	}
	
public int setMammoPoseidonData(ArrayList<MammoPoseidon> mammoPoseidonData) {
		
		final String Query = "insert into onwatch.xr_mamo_poseidon_event_dtl (tar_systemid,msg_date,activity_datetime,short_text,activity_parameter_name,activity_parameter_value) values (?,?::date,?,?,?,?)";
		
		//final String Query = "insert into public.xr_mamo_poseidon_event_dtl (tar_systemid,msg_date,activity_datetime,short_text,activity_parameter_name,activity_parameter_value) values (?,?::date,?,?,?,?)";

		Connection con = null;
		try {  

			con = this.destDatasource.getConnection();
			//step3 create the statement object  
			PreparedStatement ps=con.prepareStatement(Query);

			int i = 0;
			for(MammoPoseidon date: mammoPoseidonData) {
				ps.setString(1, date.getTar_systemid());
				ps.setString(2, date.getMsg_date());
				ps.setString(3, date.getActivity_datetime());
				ps.setString(4, date.getShort_text());
				ps.setString(5, date.getActivity_parameter_name());
				ps.setString(6, date.getActivity_parameter_value());

				ps.addBatch();

				i++;
				if (i % 1000 == 0 || i == mammoPoseidonData.size()) {
					int[] results=ps.executeBatch(); // Execute every 1000 items.
					System.out.println("Number of mammo poseidon rows inserted: "+ results.length);
					/*System.out.println("In results:--->");
					for(int x:results) {
						
						System.out.print(x+" ");
					}*/
				}
			}
			return i;
		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Error while inserting mammoPoseidonData :"+e);
			e.printStackTrace();
			return -1;
		}finally
		{
			//step5 close the connection object  
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
		
	}

}
