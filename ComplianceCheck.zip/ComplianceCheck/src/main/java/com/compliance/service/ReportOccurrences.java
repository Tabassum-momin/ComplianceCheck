package com.compliance.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ge.ibdc.monitoring.bean.ReportKeyValue;

@Service
@Repository()
public class ReportOccurrences {

	@Autowired
	private DataSource datasource;
	
	@Qualifier("datasource2")
	@Autowired
	private DataSource destDatasource;

	public ArrayList<ReportKeyValue> getReportOccurrences(String startTime, String endTime, String systemId)
	{			
		final String QUERY_REPORT_OCCURRECNES ="select status, count(*), "
				+ "decode(report_type, 'Notification', 'Dose Notification', 'Dose', 'Dose Summary', 'OnWatch','OnWatch Summary' , report_Type ) as report_type from report where \r\n" +
				"creationdate >= TO_TIMESTAMP('"+startTime+"', 'YYYY-MM-DD') \r\n"+
				"and creationdate < TO_TIMESTAMP('"+endTime+"', 'YYYY-MM-DD') \r\n"+
				"group by status,report_type";
		final String QUERY_REPORT2_OCCURRECNES ="select status, count(*), "
				+ "decode(report_type, 'Notification', 'Dose Notification', 'Dose', 'Dose Summary', 'OnWatch','OnWatch Summary' , report_Type ) as report_type from report where "
				+ "creationdate >= TO_TIMESTAMP('"+startTime+"', 'YYYY-MM-DD')\r\n" + 
				"and creationdate < TO_TIMESTAMP('"+endTime+"', 'YYYY-MM-DD')\r\n" + 
				"and system_id in (select id from equipment where systemid='"+systemId+"')\r\n" + 
				"group by status,report_type";
		final String Query = "select tar_systemid, exam_starttime, exam_endtime from onwatch.xr_vasc_rob_dtl where tar_systemid='083016807113915' and msg_date='2019-09-26'";

		Connection con = null;
		ArrayList<ReportKeyValue> reportCount = null; 

		try {  

			con = this.datasource.getConnection();
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			ResultSet rs;
			//step4 execute query  
			if( systemId.equals("") ){
				rs=stmt.executeQuery(Query);
			}
			else {
				rs=stmt.executeQuery(Query);	
			}
			if(rs!=null)
			{
				reportCount = new ArrayList<ReportKeyValue>();
				ReportKeyValue ReportkeyValue = null;
				while(rs.next())
				{
					ReportkeyValue= new ReportKeyValue(rs.getString(1), rs.getString(2),rs.getString(3));
					reportCount.add(ReportkeyValue);
					System.out.println(rs.getString(1) +":"+ rs.getString(2) +":"+ rs.getString(3));
				}
			}

		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Error while retreiving Report Occurrences:"+e);
			e.printStackTrace();
		}finally
		{
			//step5 close the connection object  
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
		return reportCount;
	}

	public boolean saveDates(ArrayList<ReportKeyValue> dates) {
		final String Query = "insert into owqa.xr_vasc_rob_dtl (tar_systemid, exam_starttime, exam_endtime) values (?,?,?)";

		Connection con = null;
		ArrayList<ReportKeyValue> reportCount = null; 

		try {  

			con = this.destDatasource.getConnection();
			//step3 create the statement object  
			PreparedStatement ps=con.prepareStatement(Query);

			int i = 0;
			for(ReportKeyValue date: dates) {
				ps.setString(1, date.getKey());
				ps.setString(2, date.getValue());
				ps.setString(3, date.getType());

				ps.addBatch();

				i++;
				if (i % 1000 == 0 || i == dates.size()) {
					ps.executeBatch(); // Execute every 1000 items.
				}
			}
			return true;
		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Error while retreiving Report Occurrences:"+e);
			e.printStackTrace();
			return false;
		}finally
		{
			//step5 close the connection object  
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
	}
}
