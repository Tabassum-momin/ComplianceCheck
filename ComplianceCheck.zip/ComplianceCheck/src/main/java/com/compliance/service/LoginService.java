package com.compliance.service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	
	/*
	 * @Autowired QueryService queryService;
	 */
	
public boolean validateUser(String email){
	/*try{
	String query = queryService.fetchQuery("user");
	query = String.format(query, email);
	System.out.println(query);
	ResultSet rs  = queryService.executeQuery(query);
	while(rs.next()) 
		return true;
	}
	catch(Exception e){
		e.printStackTrace();
	}*/
	return true;
	}
	
}
