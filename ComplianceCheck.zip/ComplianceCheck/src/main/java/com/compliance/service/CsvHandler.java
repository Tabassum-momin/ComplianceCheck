package com.compliance.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
@Repository()
public class CsvHandler {		
	public ArrayList<String> readData(String file) throws IOException {
		
		ArrayList<String> content = new ArrayList<>();
		try(BufferedReader br = new BufferedReader(new FileReader(file))) {
			String line = null;
			while ((line = br.readLine()) != null) {
				content.add(line);
				System.out.println("Systemid = " + line);
			}
		} catch (FileNotFoundException e) {
			//Some error logging
			e.printStackTrace();
		}
		// for (String[] s : content) { System.out.println(s); }
		return content;
	}	
	
	public  void createData(String filename, String CSV_HEADER) throws IOException{
		
		FileWriter fileWriter = null;
        File newFile = new File(filename);
		if(newFile.exists()) {
			//newFile.delete();
			System.out.println("File already exist. Appending data to same file...");
			}
		try {
			fileWriter = new FileWriter(filename,true);
			fileWriter.append(CSV_HEADER);
			fileWriter.append('\n');
		System.out.println("Create CSV file and add Header successfully!");
		} catch (Exception e) {
			System.out.println("Writing CSV error!");
			e.printStackTrace();
		} finally {
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Flushing/closing error!");
				e.printStackTrace();
			}
		}

	}
		
	public ArrayList<String> writeData(String filename,Integer errorCount, Integer robCount,String systemid) throws IOException{
		
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(filename,true);
			fileWriter.append(systemid);
			fileWriter.append(',');
			fileWriter.append(errorCount.toString());
			fileWriter.append(',');
			fileWriter.append(robCount.toString());
			fileWriter.append(',');
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			fileWriter.append(timestamp.toString());			
			fileWriter.append('\n');
		System.out.println("Append "+systemid+" data successfully in CSV file!");
		} catch (Exception e) {
			System.out.println("Appending data CSV error!");
			e.printStackTrace();
		} finally {
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Flushing/closing error!");
				e.printStackTrace();
			}
		}
		
		return null;
		
	}
	
public ArrayList<String> mammoWriteData(String filename,Integer errorCount, Integer examCount,Integer poseidonCount,String systemid) throws IOException{
		
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(filename,true);
			fileWriter.append(systemid);
			fileWriter.append(',');
			fileWriter.append(errorCount.toString());
			fileWriter.append(',');
			fileWriter.append(examCount.toString());
			fileWriter.append(',');
			fileWriter.append(poseidonCount.toString());
			fileWriter.append(',');
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			fileWriter.append(timestamp.toString());	
			fileWriter.append('\n');
		System.out.println("Append "+systemid+" data successfully in CSV file!");
		} catch (Exception e) {
			System.out.println("Appending data CSV error!");
			e.printStackTrace();
		} finally {
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Flushing/closing error!");
				e.printStackTrace();
			}
		}
		
		return null;
		
	}


}
