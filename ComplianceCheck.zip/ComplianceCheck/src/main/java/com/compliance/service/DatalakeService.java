package com.compliance.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.ge.ibdc.monitoring.bean.MammoError;

@Service
public class DatalakeService {

	public String getAccessToken () {
		HttpURLConnection connection = null;
		//JSONStringer parser = new JSONStringer();
		BufferedReader reader;
		String line;
		StringBuffer responseContent = new StringBuffer();
		try {
			URL url = new URL("https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&scope=api&client_id=GEHealth-om8VJ1pnTX1eoWKTFehxF20u&client_secret=aeca45372ee7000661d7c3b07eaecb5f6e006547");
			connection = (HttpURLConnection) url.openConnection();

			connection.setRequestMethod("POST");
			connection.setConnectTimeout(60000);
			connection.setConnectTimeout(60000);
			//connection.setRequestProperty("grant_type", "client_credentials");
			//connection.setRequestProperty("scope", "api");
			//connection.setRequestProperty("client_id", "GEHealth-om8VJ1pnTX1eoWKTFehxF20u");
			//connection.setRequestProperty("client_secret", "aeca45372ee7000661d7c3b07eaecb5f6e006547");

			int status = connection.getResponseCode();
			System.out.println("Response Status Code : " + status);

			if(status > 299) {
				reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
				while((line = reader.readLine()) != null) {
					responseContent.append(line);
				}
				reader.close();
			} else {
				reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				while((line = reader.readLine()) != null) {
					responseContent.append(line);
				}
				reader.close();
				JSONObject jsonObj = new JSONObject(responseContent.toString());
				return jsonObj.getString("access_token");
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.disconnect();
		}
		return null;
	}

	public String getEncodedQueryString (String accessToken, String systemId, String logDate) {
		HttpURLConnection connection = null;
		BufferedReader reader;
		String line;
		String queryString = "SELECT activity_time,sub_system,activity_id,short_text,recovery_class,major_function,minor_function,viewing_level from onwatch.xr_mamo_error_dtl where tar_systemid='"+systemId +"'and msg_date='"+logDate +"'";
		String authorizationCode = "Bearer " + accessToken;
		StringBuffer responseContent = new StringBuffer();
		try {
			URL url = new URL("https://api.ge.com/healthcare/api/mdp/daas/encrypt/v1");
			connection = (HttpURLConnection) url.openConnection();
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);
			connection.setRequestProperty("Authorization", authorizationCode);
			connection.setRequestProperty("Content-type", "text/plain");
			OutputStream outputStream = connection.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(outputStream, "UTF-8");
			osw.write(queryString);
			osw.flush();
			osw.close();
			outputStream.close();
			//connection.connect();
			int status = connection.getResponseCode();
			System.out.println("Response Status Code : " + status);
			if(status > 299) {
				reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
				while((line = reader.readLine()) != null) {
					responseContent.append(line);
				}
				reader.close();
			} else {
				reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				while((line = reader.readLine()) != null) {
					responseContent.append(line);
				}
				reader.close();
				return responseContent.toString();
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.disconnect();
		}
		return null;
	}
	
	public ArrayList<MammoError> getDLData(String userName, String accessToken, String encodedString) {
		HttpURLConnection connection = null;
		BufferedReader reader;
		String line;
		String authorizationCode = "Bearer " + accessToken;
		StringBuffer responseContent = new StringBuffer();
		String bodyString = "{\r\n" + 
				"\"userName\" : \"" + userName + "\",\r\n" + 
				"\"queryString\" : \""+ encodedString + "\",\r\n" + 
				"\"appName\" : \"IBDC_PROD\",\r\n" + 
				"\"pageNumber\":1\r\n" + 
				"}";
		try {
			URL url = new URL("https://api.ge.com/healthcare/api/mdp/daas/sso/MachineDataFetch/v1");
			connection = (HttpURLConnection) url.openConnection();
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);
			connection.setRequestProperty("Authorization", authorizationCode);
			connection.setRequestProperty("Content-type", "application/json");
			OutputStream outputStream = connection.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(outputStream, "UTF-8");
			osw.write(bodyString);
			osw.flush();
			osw.close();
			outputStream.close();
			//connection.connect();
			int status = connection.getResponseCode();
			System.out.println("Response Status Code : " + status);
			if(status > 299) {
				reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
				while((line = reader.readLine()) != null) {
					responseContent.append(line);
				}
				reader.close();
			} else {
				reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				while((line = reader.readLine()) != null) {
					responseContent.append(line);
				}
				reader.close();
				ArrayList<MammoError> mammoerrorlist =new ArrayList<MammoError>();
				MammoError mammo_error = null;
				JSONObject jsonObject = new JSONObject(responseContent.toString());
				mammoerrorlist = (ArrayList<MammoError>)(jsonObject.get("data"));
			    
				return mammoerrorlist;
			}
			//TODO check response code and through exception
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.disconnect();
		}
		return null;
	}
}
