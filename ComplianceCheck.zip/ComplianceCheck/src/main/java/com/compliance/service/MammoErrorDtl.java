package com.compliance.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ge.ibdc.monitoring.bean.MammoError;

@Service
@Repository()
public class MammoErrorDtl {
	

	@Autowired
	private DataSource datasource = null;

	@Qualifier("datasource2")
	@Autowired
	private DataSource destDatasource; 
	

	/**
	 * Get list of active MAMMO Error List 
	 */
	public ArrayList<MammoError> getMammoErrorData(String systemId,String msgDate){

		Connection con = null;
		ArrayList<MammoError> mammoerrorlist = null;
		try {  

			con = this.datasource.getConnection();
				    
		    //Sql Query
			final String query = "SELECT activity_time,sub_system,activity_id,short_text,recovery_class,major_function,minor_function,viewing_level from onwatch.xr_mamo_error_dtl where tar_systemid=? and msg_date=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, systemId);
			ps.setString(2, msgDate);

			ResultSet rs=ps.executeQuery();
			if(rs!=null) {				
				mammoerrorlist =new ArrayList<MammoError>();
				MammoError mammo_error = null;
				while(rs.next()) {
					mammo_error= new MammoError(rs.getString(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
					mammo_error.setTar_systemid(systemId);
					mammo_error.setMsg_date(msgDate);
					mammoerrorlist.add(mammo_error);
					//System.out.println(vascerrorlist);
				}
				for (MammoError s : mammoerrorlist) { System.out.println(s); break; }
			}
			else {
				return null;
			}

		}catch (Exception e) {
			System.err.println("Error while retreiving mammoerrorlist:"+e);
			e.printStackTrace();
		}finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
		return mammoerrorlist;
	}

	public int setMammoErrorData(ArrayList<MammoError> mammoErrorData) {
		
		final String Query = "insert into onwatch.xr_mamo_error_dtl (tar_systemid,msg_date,activity_time,sub_system,activity_id,short_text,recovery_class,major_function,minor_function,viewing_level) values (?,?::date,?,?,?,?,?,?,?,?::INTEGER)";
		
		//final String Query = "insert into public.xr_mamo_error_dtl (tar_systemid,msg_date,activity_time,sub_system,activity_id,short_text,recovery_class,major_function,minor_function,viewing_level) values (?,?::date,?,?,?,?,?,?,?,?::INTEGER)";

		Connection con = null;
		try {  

			con = this.destDatasource.getConnection();
			//step3 create the statement object  
			PreparedStatement ps=con.prepareStatement(Query);

			int i = 0;
			for(MammoError date: mammoErrorData) {
				ps.setString(1, date.getTar_systemid());
				ps.setString(2, date.getMsg_date());
				ps.setString(3, date.getActivity_time());
				ps.setString(4, date.getSub_system());
				ps.setString(5, date.getActivity_id());
				ps.setString(6, date.getShort_text());
				ps.setString(7, date.getRecovery_class());
				ps.setString(8, date.getMajor_function());
				ps.setString(9, date.getMinor_function());
				ps.setString(10, date.getViewing_level());

				ps.addBatch();

				i++;
				if (i % 1000 == 0 || i == mammoErrorData.size()) {
					int[] results=ps.executeBatch(); // Execute every 1000 items.
					System.out.println("Number of mammo error rows inserted: "+ results.length);
					/*System.out.println("In results:--->");
					for(int x:results) {
						
						System.out.print(x+" ");
					}*/
				}
			}
			return i;
		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Error while inserting mammoErrorData :"+e);
			e.printStackTrace();
			return -1;
		}finally
		{
			//step5 close the connection object  
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
		
	}
	
	public boolean checkMamoExistingdata(String systemId, String msgDate){
		
		final String queryCheck = "select * from onwatch.xr_mamo_error_dtl where tar_systemid=? and msg_date=?::date limit 2";
		
		//final String queryCheck = "select * from public.xr_mamo_error_dtl where tar_systemid=? and msg_date=?::date limit 2";
		
		Connection con = null;
			try {
				con = this.destDatasource.getConnection();
				PreparedStatement exist=con.prepareStatement(queryCheck,ResultSet.TYPE_SCROLL_INSENSITIVE, 
                        ResultSet.CONCUR_UPDATABLE);
				exist.setString(1, systemId);
				exist.setString(2, msgDate);
				ResultSet rs1=exist.executeQuery();
				int count =0;
				rs1.last();
		        count = rs1.getRow();
		        rs1.beforeFirst();
		        //System.out.println(rs1.last());
		        
				if(rs1!=null && count>0) {
					System.out.println(count);
					// data already exists
					return true;
				}
				else {
					return false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				//close the connection object  
				try {
					con.close();
				} catch (SQLException e) {
					System.err.println("Error while closing connection:"+e);
					e.printStackTrace();
				}
			}
			return false;								
	}

}
