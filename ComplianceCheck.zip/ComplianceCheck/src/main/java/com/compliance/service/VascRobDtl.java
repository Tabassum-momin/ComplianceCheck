package com.compliance.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import com.ge.ibdc.monitoring.bean.VascRob;

@Service
@Repository()
public class VascRobDtl {
	
	@Autowired
	private DataSource datasource = null;

	@Qualifier("datasource2")
	@Autowired
	private DataSource destDatasource; 
	 
	/**
	 * Get list of active VASC Rob Exam List 
	 */
	public ArrayList<VascRob> getVascRobExamData(String systemId, String msgDate){

		Connection con = null;
		ArrayList<VascRob> vascroblist = null;
		try {  

			con = this.datasource.getConnection();
				    
		    //Sql Query
			final String query = "SELECT exam_starttime,exam_endtime,exam_istest,exam_key_type,exam_patientid,exam_euid,fluoro_starttime,fluoro_endtime,fluoro_protocol,record_starttime,record_endtime,record_protocol,acq_nimages,acq_actor,acq_pipeid,acq_param_actor,acq_param_frame_rate,acq_param_fov,acq_param_mas,acq_param_kvp,acq_param_traj_fam_id,acq_param_sid,acq_param_sod,acq_abort_time,acq_abort_type,acq_abort_errorcode,imchainpos_icp_arcangle,imchainpos_icp_larmangle,imchainpos_icp_pivotangle,imchainpos_icp_laorao,imchainpos_icp_cracau,imchainpos_icp_actor,imchainpos_sidssdsod_actor,imchainpos_sidssdsod_sid,imchainpos_sidssdsod_sod,agvmotionenable_actor,agvmotionenable_agv_lat_pos,agvmotionenable_agv_long_pos,agvmotionenable_swivel_angle,bootfailure_time,bootfailure_cause,bootfailure_actor,reset_requesttime,reset_sysreadytime,shutdown_requesttime,shutdown_sysreadytime,patpos_lat,patpos_long,patpos_tilt,patpos_vert,push_time,push_jobid,push_mode,protocol_selection_accesstime,protocol_selection_status,protocol_selection_name,protocol_selection_list,msg_time from onwatch.xr_vasc_rob_dtl where tar_systemid=? and msg_date=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, systemId);
			ps.setString(2, msgDate);

			ResultSet rs=ps.executeQuery();
			if(rs!=null) {				
				vascroblist =new ArrayList<VascRob>();
				VascRob vasc_rob = null;
				while(rs.next()) {
					vasc_rob= new VascRob(rs.getString(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12),rs.getString(13),rs.getString(14),rs.getString(15),rs.getString(16),rs.getString(17),rs.getString(18),rs.getString(19),rs.getString(20),rs.getString(21),rs.getString(22),rs.getString(23),rs.getString(24),rs.getString(25),rs.getString(26),rs.getString(27),rs.getString(28),rs.getString(29),rs.getString(30),rs.getString(31),rs.getString(32),rs.getString(33),rs.getString(34),rs.getString(35),rs.getString(36),rs.getString(37),rs.getString(38),rs.getString(39),rs.getString(40),rs.getString(41),rs.getString(42),rs.getString(43),rs.getString(44),rs.getString(45),rs.getString(46),rs.getString(47),rs.getString(48),rs.getString(49),rs.getString(50),rs.getString(51),rs.getString(52),rs.getString(53),rs.getString(54),rs.getString(55),rs.getString(56),rs.getString(57),rs.getString(58));
					vasc_rob.setTar_systemid(systemId);
					vasc_rob.setMsg_date(msgDate);
					vascroblist.add(vasc_rob);
					//System.out.println(vascerrorlist);
				}
				for (VascRob s : vascroblist) { System.out.println(s); break;}
			}
			else {
				return null;
			}

		}catch (Exception e) {
			System.err.println("Error while retreiving VascRobList:"+e);
			e.printStackTrace();
		}finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
		return vascroblist;
	}
	
	public int setVascRobData(ArrayList<VascRob> vascRobData) {
		
		final String Query = "insert into onwatch.xr_vasc_rob_dtl (tar_systemid,msg_date,exam_starttime,exam_endtime,exam_istest,exam_key_type,exam_patientid,exam_euid,fluoro_starttime,fluoro_endtime,fluoro_protocol,record_starttime,record_endtime,record_protocol,acq_nimages,acq_actor,acq_pipeid,acq_param_actor,acq_param_frame_rate,acq_param_fov,acq_param_mas,acq_param_kvp,acq_param_traj_fam_id,acq_param_sid,acq_param_sod,acq_abort_time,acq_abort_type,acq_abort_errorcode,imchainpos_icp_arcangle,imchainpos_icp_larmangle,imchainpos_icp_pivotangle,imchainpos_icp_laorao,imchainpos_icp_cracau,imchainpos_icp_actor,imchainpos_sidssdsod_actor,imchainpos_sidssdsod_sid,imchainpos_sidssdsod_sod,agvmotionenable_actor,agvmotionenable_agv_lat_pos,agvmotionenable_agv_long_pos,agvmotionenable_swivel_angle,bootfailure_time,bootfailure_cause,bootfailure_actor,reset_requesttime,reset_sysreadytime,shutdown_requesttime,shutdown_sysreadytime,patpos_lat,patpos_long,patpos_tilt,patpos_vert,push_time,push_jobid,push_mode,protocol_selection_accesstime,protocol_selection_status,protocol_selection_name,protocol_selection_list,msg_time) values (?,?::date,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		//final String Query = "insert into public.xr_vasc_rob_dtl (tar_systemid,msg_date,exam_starttime,exam_endtime,exam_istest,exam_key_type,exam_patientid,exam_euid,fluoro_starttime,fluoro_endtime,fluoro_protocol,record_starttime,record_endtime,record_protocol,acq_nimages,acq_actor,acq_pipeid,acq_param_actor,acq_param_frame_rate,acq_param_fov,acq_param_mas,acq_param_kvp,acq_param_traj_fam_id,acq_param_sid,acq_param_sod,acq_abort_time,acq_abort_type,acq_abort_errorcode,imchainpos_icp_arcangle,imchainpos_icp_larmangle,imchainpos_icp_pivotangle,imchainpos_icp_laorao,imchainpos_icp_cracau,imchainpos_icp_actor,imchainpos_sidssdsod_actor,imchainpos_sidssdsod_sid,imchainpos_sidssdsod_sod,agvmotionenable_actor,agvmotionenable_agv_lat_pos,agvmotionenable_agv_long_pos,agvmotionenable_swivel_angle,bootfailure_time,bootfailure_cause,bootfailure_actor,reset_requesttime,reset_sysreadytime,shutdown_requesttime,shutdown_sysreadytime,patpos_lat,patpos_long,patpos_tilt,patpos_vert,push_time,push_jobid,push_mode,protocol_selection_accesstime,protocol_selection_status,protocol_selection_name,protocol_selection_list,msg_time) values (?,?::date,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		Connection con = null;
		try {  

			con = this.destDatasource.getConnection();
			//step3 create the statement object  
			PreparedStatement ps=con.prepareStatement(Query);

			int i = 0;
			for(VascRob date: vascRobData) {
				ps.setString(1, date.getTar_systemid());
				ps.setString(2, date.getMsg_date());
				ps.setString(3, date.getExam_starttime());
				ps.setString(4, date.getExam_endtime());
				ps.setString(5, date.getExam_istest());
				ps.setString(6, date.getExam_key_type());
				ps.setString(7, date.getExam_patientid());
				ps.setString(8, date.getExam_euid());
				ps.setString(9, date.getFluoro_starttime());
				ps.setString(10, date.getFluoro_endtime());
				ps.setString(11, date.getFluoro_protocol());
				ps.setString(12, date.getRecord_starttime());
				ps.setString(13, date.getRecord_endtime());
				ps.setString(14, date.getRecord_protocol());
				ps.setString(15, date.getAcq_nimages());
				ps.setString(16, date.getAcq_actor());
				ps.setString(17, date.getAcq_pipeid());
				ps.setString(18, date.getAcq_param_actor());
				ps.setString(19, date.getAcq_param_frame_rate());
				ps.setString(20, date.getAcq_param_fov());
				ps.setString(21, date.getAcq_param_mas());
				ps.setString(22, date.getAcq_param_kvp());
				ps.setString(23, date.getAcq_param_traj_fam_id());
				ps.setString(24, date.getAcq_param_sid());
				ps.setString(25, date.getAcq_param_sod());
				ps.setString(26, date.getAcq_abort_time());
				ps.setString(27, date.getAcq_abort_type());
				ps.setString(28, date.getAcq_abort_errorcode());
				ps.setString(29, date.getImchainpos_icp_arcangle());
				ps.setString(30, date.getImchainpos_icp_larmangle());
				ps.setString(31, date.getImchainpos_icp_pivotangle());
				ps.setString(32, date.getImchainpos_icp_laorao());
				ps.setString(33, date.getImchainpos_icp_cracau());
				ps.setString(34, date.getImchainpos_icp_actor());
				ps.setString(35, date.getImchainpos_sidssdsod_actor());
				ps.setString(36, date.getImchainpos_sidssdsod_sid());
				ps.setString(37, date.getImchainpos_sidssdsod_sod());
				ps.setString(38, date.getAgvmotionenable_actor());
				ps.setString(39, date.getAgvmotionenable_agv_lat_pos());
				ps.setString(40, date.getAgvmotionenable_agv_long_pos());
				ps.setString(41, date.getAgvmotionenable_swivel_angle());
				ps.setString(42, date.getBootfailure_time());
				ps.setString(43, date.getBootfailure_cause());
				ps.setString(44, date.getBootfailure_actor());
				ps.setString(45, date.getReset_requesttime());
				ps.setString(46, date.getReset_sysreadytime());
				ps.setString(47, date.getShutdown_requesttime());
				ps.setString(48, date.getShutdown_sysreadytime());
				ps.setString(49, date.getPatpos_lat());
				ps.setString(50, date.getPatpos_long());
				ps.setString(51, date.getPatpos_tilt());
				ps.setString(52, date.getPatpos_vert());
				ps.setString(53, date.getPush_time());
				ps.setString(54, date.getPush_jobid());
				ps.setString(55, date.getPush_mode());
				ps.setString(56, date.getProtocol_selection_accesstime());
				ps.setString(57, date.getProtocol_selection_status());
				ps.setString(58, date.getProtocol_selection_name());
				ps.setString(59, date.getProtocol_selection_list());
				ps.setString(60, date.getMsg_time());
				

				ps.addBatch();

				i++;
				if (i % 1000 == 0 || i == vascRobData.size()) {
					int[] results=ps.executeBatch(); // Execute every 1000 items.
					System.out.println("Number of Vasc rob rows inserted: "+ results.length);
					/*System.out.println("In results:--->");
					for(int x:results) {
						
						System.out.print(x+" ");
					}*/
				}
			}
			return i;
		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Error while inserting vascRobData :"+e);
			e.printStackTrace();
			return -1;
		}finally
		{
			//step5 close the connection object  
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
	}

}
