package com.compliance.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ge.ibdc.monitoring.bean.MammoExam;

@Service
@Repository()
public class MammoExamDtl {
	
	@Autowired
	private DataSource datasource = null;

	@Qualifier("datasource2")
	@Autowired
	private DataSource destDatasource; 
	

	/**
	 * Get list of active MAMMO Exam List 
	 */
	public ArrayList<MammoExam> getMammoExamData(String systemId, String msgDate){

		Connection con = null;
		ArrayList<MammoExam> mammoexamlist = null;
		try {  

			con = this.datasource.getConnection();
				    
		    //Sql Query
			final String query = "SELECT activity_time,short_text,patient_id,operator_name,patient_age from onwatch.xr_mamo_examevent_dtl where tar_systemid=? and msg_date=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, systemId);
			ps.setString(2, msgDate);

			ResultSet rs=ps.executeQuery();
			if(rs!=null) {				
				mammoexamlist =new ArrayList<MammoExam>();
				MammoExam mammo_exam = null;
				while(rs.next()) {
					mammo_exam= new MammoExam(rs.getString(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
					mammo_exam.setTar_systemid(systemId);
					mammo_exam.setMsg_date(msgDate);
					mammoexamlist.add(mammo_exam);
					//System.out.println(vascerrorlist);
				}
				for (MammoExam s : mammoexamlist) { System.out.println(s); break; }
			}
			else {
				return null;
			}

		}catch (Exception e) {
			System.err.println("Error while retreiving mammoexamlist:"+e);
			e.printStackTrace();
		}finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
		return mammoexamlist;
	}
	
public int setMammoExamData(ArrayList<MammoExam> mammoExamData) {
		
		final String Query = "insert into onwatch.xr_mamo_examevent_dtl (tar_systemid,msg_date,activity_time,short_text,patient_id,operator_name,patient_age) values (?,?::date,?,?,?,?,?)";
		
		//final String Query = "insert into public.xr_mamo_examevent_dtl (tar_systemid,msg_date,activity_time,short_text,patient_id,operator_name,patient_age) values (?,?::date,?,?,?,?,?)";

		Connection con = null;
		try {  

			con = this.destDatasource.getConnection();
			//step3 create the statement object  
			PreparedStatement ps=con.prepareStatement(Query);

			int i = 0;
			for(MammoExam date: mammoExamData) {
				ps.setString(1, date.getTar_systemid());
				ps.setString(2, date.getMsg_date());
				ps.setString(3, date.getActivity_time());
				ps.setString(4, date.getShort_text());
				ps.setString(5, date.getPatient_id());
				ps.setString(6, date.getOperator_name());
				ps.setString(7, date.getPatient_age());

				ps.addBatch();

				i++;
				if (i % 1000 == 0 || i == mammoExamData.size()) {
					int[] results=ps.executeBatch(); // Execute every 1000 items.
					System.out.println("Number of mammo exam rows inserted: "+ results.length);
					/*System.out.println("In results:--->");
					for(int x:results) {
						
						System.out.print(x+" ");
					}*/
				}
			}
			return i;
		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Error while inserting mammoExamData :"+e);
			e.printStackTrace();
			return -1;
		}finally
		{
			//step5 close the connection object  
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println("Error while closing connection:"+e);
				e.printStackTrace();
			}
		}
		
	}

}
